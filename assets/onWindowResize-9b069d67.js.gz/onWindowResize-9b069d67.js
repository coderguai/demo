import{au as i}from"./index-81730b21.js";function n(e){i(()=>window,"resize",e,{passive:!0}),i(()=>window,"orientationchange",e,{passive:!0})}export{n as o};
